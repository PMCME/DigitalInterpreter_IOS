//
//  VideoVC.swift
//  PjsipDemo
//
//  Created by Apple on 19/05/23.
//

import UIKit
import AVFoundation

class VideoVC: UIViewController {

    @IBOutlet var videoView : UIView!
    @IBOutlet var btnHangUp : UIButton!
    @IBOutlet var btnMute : UIButton!
    @IBOutlet var btnVideo : UIButton!
    @IBOutlet var cameraPreviewView : UIView!

    var customVideo : UIView =  UIView()
    var localVideo : UIView =  UIView()

    override func viewDidLoad() {
        super.viewDidLoad()
        print("Frame: \(videoView.frame)")
        print("custom video :\(customVideo.subviews)")
        customVideo.frame = videoView.frame
        videoView.addSubview(customVideo)
        self.cameraPreviewView.isHidden = true
        
      //  cameraPreviewView.addSubview(localVideo)
        
    }
    
    
    @IBAction func  btnHangup_Click(_ sender : UIButton) {
        DispatchQueue.global().async(execute: {
           NotificationCenter.default.post(Constant.NotificationName.HangUpCallBack)
        })
    }
    
    override func viewDidLayoutSubviews() {
      //  customVideo.frame = videoView.frame
    }
    
    
    @IBAction func btnMuteClick(_ sender : UIButton) {
        sender.isSelected =  !sender.isSelected
        if sender.isSelected {
             muteOugoingCall()
        } else {
            unMuteoutgoingCall()
        }
        
    }
    
    @IBAction func btnVideoOnOffClick( _ sender : UIButton){
        sender.isSelected =  !sender.isSelected
        if sender.isSelected {
            showRemoteVideoOnFullScreen()
        } else {
            showLocalVideoOnScreen()
        }
        
    }
  
    
}
