//
//  AppDelegate.swift
//  PjsipDemo
//
//  Created by Apple on 17/05/23.
//

import UIKit
import IQKeyboardManagerSwift

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    var orientationLock = UIInterfaceOrientationMask.portrait

    struct AppUtility {
        static func lockOrientation(_ orientation: UIInterfaceOrientationMask) {
            if let delegate = UIApplication.shared.delegate as? AppDelegate {
                delegate.orientationLock = orientation
            }
        }
            
        static func lockOrientation(_ orientation: UIInterfaceOrientationMask, andRotateTo rotateOrientation:UIInterfaceOrientation) {
            self.lockOrientation(orientation)
            UIDevice.current.setValue(rotateOrientation.rawValue, forKey: "orientation")
        }
    }

    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        IQKeyboardManager.shared.enable = true
        window?.makeKeyAndVisible()
        return true
    }

    // MARK: UISceneSession Lifecycle


    func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
        return .portrait
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        self.performSelector(onMainThread: #selector(keepAlive), with: nil, waitUntilDone: true)
    }
    
    
    @objc func keepAlive() {
        var status: pj_status_t
        let desc: UnsafeMutablePointer<Int>? = nil
           if (pj_thread_is_registered() == 0) {
                var pjThread  = pj_thread_this()
                status = pj_thread_register("ipjsua", desc, &pjThread)
                if status != PJ_SUCCESS.rawValue {
                    let errorMsg = "Error registering thread at PJSUA"
                    print(errorMsg)
                }
            }
        let count = pjsua_acc_get_count()
        print("Total Active Account: \(count)")
        let accID = pjsua_acc_get_default()
        if ((pjsua_acc_is_valid(accID)) != 0) {
            pjsua_acc_set_registration(accID, pj_bool_t(PJ_TRUE.rawValue));
        }
//        for i in 0..<count {
//
//
//        }
        
       
        
    }
    
    
}

