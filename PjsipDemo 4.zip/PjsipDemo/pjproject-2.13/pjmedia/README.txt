[Last Update: 2006/03/04]

This directory contains two static libraries:
 - pjmedia
   The multimedia framework.

 - pjmedia-codec
   Codec collections.

pjmedia has G711 codecs (Alaw and ULaw).

pjmedia-codec has:
 - GSM-FR implementation
   Copyright 1992 by Jutta Degener and Carsten Bormann, Technische
   Universitaet Berlin

 - Speex 1.1.12
   http://www.speex.org

