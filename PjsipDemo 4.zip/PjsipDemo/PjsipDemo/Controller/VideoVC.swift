//
//  VideoVC.swift
//  PjsipDemo
//
//  Created by Apple on 19/05/23.
//

import UIKit
import AVFoundation

class VideoVC: UIViewController {

    @IBOutlet var videoView : UIView!
    @IBOutlet var btnHangUp : UIButton!
    @IBOutlet var btnMute : UIButton!
    @IBOutlet var btnVideo : UIButton!
    @IBOutlet var cameraPreviewView : UIView!

    var customVideo : UIView =  UIView()
    var localVideo : UIView =  UIView()
    var dialPadView = DialPadRenderView(frame: CGRect(x: 0, y: 0, width: screenSize.width * 0.6, height: screenSize.height * 0.6))
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Frame: \(videoView.frame)")
        print("custom video :\(customVideo.subviews)")
        customVideo.frame = videoView.frame
        videoView.addSubview(customVideo)
        self.cameraPreviewView.isHidden = true
        
      //  cameraPreviewView.addSubview(localVideo)
        
    }
    
    
    @IBAction func  btnHangup_Click(_ sender : UIButton) {
        DispatchQueue.global().async(execute: {
           NotificationCenter.default.post(Constant.NotificationName.HangUpCallBack)
        })
    }
    
    override func viewDidLayoutSubviews() {
        customVideo.frame = videoView.frame
    }
    
    
    @IBAction func btnMuteClick(_ sender : UIButton) {
        sender.isSelected =  !sender.isSelected
        if sender.isSelected {
             muteOugoingCall()
        } else {
            unMuteoutgoingCall()
        }
        
    }
    
    @IBAction func btnVideoOnOffClick( _ sender : UIButton){
        sender.isSelected =  !sender.isSelected
        if sender.isSelected {
            showRemoteVideoOnFullScreen()
        } else {
            showLocalVideoOnScreen()
        }
        
    }
    
    @IBAction func btnHoldClick(_ sender : UIButton) {
        sender.isSelected =  !sender.isSelected
        if sender.isSelected {
           holdCall()
        } else {
            unHoldCall()
        }
    }
  
    @IBAction func btnDialPad_Click(_ sender : UIButton) {
        sender.isSelected =  !sender.isSelected
        if sender.isSelected {
            self.dialPadView.center.x =  self.view.center.x
            self.dialPadView.center.y = self.view.center.y
            dialPadView.dialedNumberBlock = { number in
                print("Dial number pad: \(number)")
                sendDTMFDigit(number)
                
            }
            self.view.addSubview(self.dialPadView)
            self.view.addSubview(self.dialPadView)
        } else {
            self.dialPadView.removeFromSuperview()
        }
    }
    
}
