//
//  ViewController.swift
//  PjsipDemo
//
//  Created by Apple on 17/05/23.
//

import UIKit
import SDWebImage



class PjsipVars: ObservableObject {
    @Published var calling = false
    var dest: String = ""//"sip:1002@fs.dics.se:6443;transport=tcp"
    var call_id: pjsua_call_id = PJSUA_INVALID_ID.rawValue
}


class ViewController: UIViewController {
    // Status Label
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet var loginInfoView : UIView!
    @IBOutlet var callInfoView : UIView!
    @IBOutlet var btnLogout : UIButton!
    
    // Sip settings Text Fields
    @IBOutlet weak var sipUsernameTField: UITextField!
    @IBOutlet weak var sipPasswordTField: UITextField!
    
    //Destination Uri to Making outgoing call
    @IBOutlet weak var sipDestinationUriTField: UITextField!
    @IBOutlet var imgCall : SDAnimatedImageView!
    
    var status: pj_status_t = 0;
    var objPjSip =  PjsipVars()
    var acc_id :pjsua_acc_id = -1;

    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("screen size: Width \(screenSize.width)------Height \(screenSize.height)")
       //Add Notification Observer
        NotificationCenter.default.addObserver(forName: Constant.NotificationName.HangUpCallBack.name, object: nil, queue: OperationQueue.main) { (notification) in
            self.hangupCall()
        }
        
        NotificationCenter.default.addObserver(forName: Constant.NotificationName.GetRegisterUserCallBack.name, object: nil, queue: OperationQueue.main) { (notification) in
            let isSuccess = notification.userInfo?["success"] as? Bool ?? false
             self.getUserRegisterCallback(isSuccess)
        }
       self.btnLogout.isHidden = true
        let animatedImage = SDAnimatedImage(named: "AnimatedCallNow.gif")
        imgCall.image = animatedImage

        
        self.callInfoView.isHidden = true

        
        //Done button to the keyboard
        sipUsernameTField.addDoneButtonOnKeyboard()
        sipPasswordTField.addDoneButtonOnKeyboard()
        sipDestinationUriTField.addDoneButtonOnKeyboard()
        sipUsernameTField.text = "1001"
        sipPasswordTField.text = "Demo User"
        sipDestinationUriTField.text =  "1002"
        
        status = pjsua_create();
        if (status != PJ_SUCCESS.rawValue) {
            NSLog("Failed creating pjsua");
        }

        /* Init configs */
        var cfg = pjsua_config();
        cfg.stun_srv_cnt =  2
        //cfg.stun_srv.0 = pj_str(strdup("stun:u2.xirsys.com"))
        
        cfg.stun_srv.0 = pj_str(strdup("stun:stun.l.google.com:19302"))
        cfg.stun_srv.1 = pj_str(strdup("stun:global.stun.twilio.com:3478"))
        
        var log_cfg = pjsua_logging_config();
        var media_cfg = pjsua_media_config();
        pjsua_config_default(&cfg);
        pjsua_logging_config_default(&log_cfg);
        media_cfg.vid_preview_enable_native = pj_bool_t(PJ_TRUE.rawValue);
        pjsua_media_config_default(&media_cfg);

        /* Initialize application callbacks */
        
        //cfg.cb.on_call_state =
         cfg.cb.on_call_state = on_call_state;
         cfg.cb.on_call_media_state = on_call_media_state;
         cfg.cb.on_incoming_call = on_incoming_call;
         cfg.cb.on_reg_state2 = on_reg_state2

        /* Init pjsua */
        status = pjsua_init(&cfg, &log_cfg, &media_cfg);
        
        /* Create transport */
        var transport_id = pjsua_transport_id();
        var tcp_cfg = pjsua_transport_config();
//        var tcp_Info = pjsua_transport_info();
//        tcp_Info.type_name  = pj_str(strdup("RFC2833"))
//        tcp_Info.id = transport_id
//        tcp_Info.type = PJSIP_TRANSPORT_UDP
        
        //pjsua_transport_info
        //pjsua_transport_config_default(&tcp_cfg);
        tcp_cfg.port = 5060;
        status = pjsua_transport_create(PJSIP_TRANSPORT_TCP,
                                        &tcp_cfg, &transport_id);
        
        
        status = pjsua_start();
        
      //  status = pjsua_transport_get_info(transport_id,&tcp_Info )
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
      //  AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.portrait, andRotateTo: UIInterfaceOrientation.portrait)

    }
    
    
    //Refresh Button
    @IBAction func refreshStatus(_ sender: UIButton) {
//        if (CPPWrapper().registerStateInfoWrapper()){
//            statusLabel.text = "Sip Status: REGISTERED"
//        }else {
//            statusLabel.text = "Sip Status: NOT REGISTERED"
//        }
    }
    
    
    //Login Button
    @IBAction func loginClick(_ sender: UIButton) {
    
    
        
        if self.sipUsernameTField.text == "" || self.sipPasswordTField.text == "" {
            let alert = UIAlertController(title: "SIP SETTINGS ERROR", message: "Please fill the form details", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
                switch action.style{
                    case .default:
                    print("default")
                    
                    case .cancel:
                    print("cancel")
                    
                    case .destructive:
                    print("destructive")
                    
                @unknown default:
                    fatalError()
                }
            }))
            self.present(alert, animated: true, completion: nil)
            return
        }
        
        let uName = self.sipUsernameTField.text ?? ""
        let pwd = strdup("123345");//self.sipPasswordTField.text ?? ""//123345
        let id = strdup("sip:\(uName)@fs.dics.se:12004");
        let username = strdup(uName);
        let passwd = strdup(pwd);
        let realm = strdup("fs.dics.se");//fs.dics.se
        let registrar = strdup("sip:fs.dics.se");
        let proxy = strdup("sip:fs.dics.se:12004;transport=tcp");

        var opt = pjsua_call_setting();
        opt.aud_cnt = 1;
        opt.vid_cnt = 1;
        
        pjsua_call_setting_default(&opt);
        
        var acc_cfg = pjsua_acc_config();
        pjsua_acc_config_default(&acc_cfg);
        acc_cfg.reg_timeout = 600;
        acc_cfg.sip_stun_use = PJSUA_STUN_RETRY_ON_FAILURE;
        acc_cfg.media_stun_use = PJSUA_STUN_RETRY_ON_FAILURE;
        acc_cfg.id = pj_str(id);
        acc_cfg.cred_count = 1;
        acc_cfg.cred_info.0.username = pj_str(username);
        acc_cfg.cred_info.0.realm = pj_str(realm);
        acc_cfg.cred_info.0.data = pj_str(passwd);
        acc_cfg.reg_uri = pj_str(registrar);
        
        acc_cfg.proxy_cnt = 1;
        acc_cfg.proxy.0 = pj_str(proxy);
        acc_cfg.vid_out_auto_transmit = pj_bool_t(PJ_TRUE.rawValue);
        acc_cfg.vid_in_auto_show = pj_bool_t(PJ_TRUE.rawValue);
        acc_cfg.vid_cap_dev = PJMEDIA_VID_DEFAULT_CAPTURE_DEV.rawValue;
        acc_cfg.vid_rend_dev = PJMEDIA_VID_DEFAULT_RENDER_DEV.rawValue;
        acc_cfg.vid_wnd_flags = PJMEDIA_VID_DEV_WND_RESIZABLE.rawValue;
        acc_cfg.reg_retry_interval = 300;
        acc_cfg.reg_first_retry_interval = 30;
        acc_cfg.turn_cfg_use = PJSUA_TURN_CONFIG_USE_CUSTOM;
        
        var turn_cfg = pjsua_turn_config()
        turn_cfg.enable_turn = pj_bool_t(PJ_TRUE.rawValue);
        turn_cfg.turn_conn_type = pj_turn_tp_type(PJ_TURN_TP_TCP.rawValue);
        turn_cfg.turn_server =  pj_str(strdup("turn:u2.xirsys.com:3478?transport=tcp"));
        
        var stunAuthCred = pj_stun_auth_cred()
        stunAuthCred.type = pj_stun_auth_cred_type(PJ_STUN_AUTH_CRED_STATIC.rawValue)
        stunAuthCred.data.static_cred.realm = pj_str(strdup("fs.dics.se"))
        stunAuthCred.data.static_cred.username = pj_str(strdup("bbe4fa8c-27c1-11e8-b16e-4bde959dd7c3"))
        stunAuthCred.data.static_cred.data = pj_str(strdup("bbe4fb04-27c1-11e8-ab22-148c78a95c7e"))
        turn_cfg.turn_auth_cred = stunAuthCred
        acc_cfg.turn_cfg = turn_cfg
        
        
        
        /* Add account */
        let accountAddStaus = pjsua_acc_add(&acc_cfg, pj_bool_t(PJ_TRUE.rawValue), &acc_id);
//        if accountAddStaus != PJ_SUCCESS.rawValue {
//            statusLabel.text = "Sip Status: NOT REGISTERED"
//        } else {
//            statusLabel.text = "Sip Status: REGISTERED"
//        }
        
        /* Free strings */
        free(id); free(username); free(passwd); free(realm);
        free(registrar); free(proxy);
        
//        var new_orientation = pjmedia_vid_dev_cap(PJMEDIA_VID_DEV_CAP_ORIENTATION.rawValue)
//
//        var param =  pjmedia_vid_dev_param()
//      //  param.clock_rate = 0
//        param.orient =  pjmedia_orient(PJMEDIA_ORIENT_ROTATE_270DEG.rawValue)
//        pjmedia_vid_dev_param_set_cap(&param,
//                                               pjmedia_vid_dev_cap(PJMEDIA_VID_DEV_CAP_ORIENTATION.rawValue),
//                                      &new_orientation);
        
        //set orientation in potrait mode.
//        var orient = pjmedia_orient(PJMEDIA_ORIENT_ROTATE_90DEG.rawValue)
//        pjsua_vid_dev_set_setting(PJMEDIA_VID_DEFAULT_CAPTURE_DEV.rawValue,
//                                  PJMEDIA_VID_DEV_CAP_ORIENTATION, &orient, pj_bool_t(PJ_TRUE.rawValue));
        
//        pjsua_vid_dev_set_setting(PJMEDIA_VID_DEFAULT_CAPTURE_DEV.rawValue,
//                                  PJMEDIA_VID_DEV_CAP_INPUT_PREVIEW, &orient, pj_bool_t(PJ_FALSE.rawValue));
        
        //pjsua_vid_dev_set_setting(PJMEDIA_VID_DEFAULT_CAPTURE_DEV.rawValue,
                                //  PJMEDIA_VID_DEV_CAP_OUTPUT_WINDOW, &orient, pj_bool_t(PJ_TRUE.rawValue));
        
       // pjsua_vid_dev_set_setting(PJMEDIA_VID_DEFAULT_RENDER_DEV.rawValue,
                               //   PJMEDIA_VID_DEV_CAP_OUTPUT_FULLSCREEN, &orient, pj_bool_t(PJ_TRUE.rawValue));
        
       //PJMEDIA_VID_DEV_CAP_OUTPUT_FULLSCREEN
        
       // PJMEDIA_VID_DEV_CAP_OUTPUT_WINDOW
      
        
        /* Start pjsua */
       
        
    }
    
    //Logout Button
    @IBAction func logoutClick(_ sender: UIButton) {
        let accountAddStaus = pjsua_acc_del(acc_id)
        
        if accountAddStaus == PJ_SUCCESS.rawValue {
            statusLabel.text = "Sign in to DCS"
            self.loginInfoView.isHidden = false
            self.callInfoView.isHidden = true
            self.btnLogout.isHidden = true
        } else {
            statusLabel.text = "USER REGISTERED"
        }
        
    }

    //Call Button
    @IBAction func callClick(_ sender: UIButton) {
        if isCallingPhone {
            print("return call")
            return
        }
        isCallingPhone = true
        self.view.endEditing(true)
        let destination = "1002"//self.sipDestinationUriTField.text ?? ""
        objPjSip.dest  = "sip:\(destination)@fs.dics.se:12004;transport=tcp"//:6443;transport=tcp"
        let user_data = UnsafeMutableRawPointer(Unmanaged.passUnretained(objPjSip).toOpaque())
        
        //call_func(user_data: user_data, account_id: acc_id)
        pjsua_schedule_timer2_dbg(call_func, user_data, 0, "swift", 0)
    }
    
    func hangupCall(){
        
        if (self.objPjSip.call_id != PJSUA_INVALID_ID.rawValue) {
            //DispatchQueue.main.sync {
                self.objPjSip.calling = false;
           // }
//            pjsua_call_hangup(self.objPjSip.call_id, 200, nil, nil);
            self.objPjSip.call_id = PJSUA_INVALID_ID.rawValue;
            if (incomingCallID != PJSUA_INVALID_ID.rawValue) {
                hangup_allCall()
            } else  {
              let status = pjsua_call_hangup(self.objPjSip.call_id, 200, nil, nil);
                if status == PJ_SUCCESS.rawValue {
                    isCallingPhone = false
                    print("Hangup call ============== 267")
                }
            }
        } else {
            if (incomingCallID != PJSUA_INVALID_ID.rawValue) {
                hangup_allCall()
            }
        }
    }
    
    func getUserRegisterCallback( _ isSuccess : Bool) {
        
    
       if !isSuccess {
           statusLabel.text = "USER NOT REGISTERED"
       } else {
           statusLabel.text = "USER REGISTERED"
           self.loginInfoView.isHidden = true
           self.callInfoView.isHidden = false
           self.btnLogout.isHidden = false
       }
        
    }
    
  
    override var shouldAutorotate: Bool {
        return true
    }

//    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
//        return UIInterfaceOrientationMask.all
//    }
//
//    override var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation {
//        return UIInterfaceOrientation.all
//    }

    
}







/*
 **> Please check this registration  scenarios**

     pj_status_t sip_startup(app_config_t *app_config)
     {
       pj_status_t status;
       long val;
       char tmp[80];
       pjsua_transport_id transport_id = -1;
       const char *srv;
           const char *ip_addr;

       NSArray * array;
       NSString *dns;

       SiphonApplication *app = (SiphonApplication *)[SiphonApplication sharedApplication];

       /* Create pjsua first! */
       status = pjsua_create();
       if (status != PJ_SUCCESS)
         return status;

       /* Create pool for application */
       app_config->pool = pjsua_pool_create("pjsua", 1000, 1000);

       /* Initialize default config */
       pjsua_config_default(&(app_config->cfg));
       pj_ansi_snprintf(tmp, 80, "Siphon PjSip v%s/%s", pj_get_version(), PJ_OS_NAME);
       pj_strdup2_with_null(app_config->pool, &(app_config->cfg.user_agent), tmp);

       pjsua_logging_config_default(&(app_config->log_cfg));

       val = [[NSUserDefaults standardUserDefaults] integerForKey:
              @"logLevel"];
     #ifdef RELEASE_VERSION
       app_config->log_cfg.msg_logging = PJ_FALSE;
       app_config->log_cfg.console_level = 0;
       app_config->log_cfg.level = 0;
     #else
       app_config->log_cfg.msg_logging = (val!=0 ? PJ_TRUE : PJ_FALSE);
       app_config->log_cfg.console_level = val;
       app_config->log_cfg.level = val;
       if (val != 0)
       {
     #if defined(CYDIA) && (CYDIA == 1)
         NSArray *filePaths = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
         NSString *path = [NSString stringWithFormat:@"%@/Siphon", [filePaths objectAtIndex:0]];
     #else
         NSArray *filePaths =    NSSearchPathForDirectoriesInDomains (NSDocumentDirectory,
                                                                    NSUserDomainMask,
                                                                    YES);
             NSString *path = [filePaths objectAtIndex: 0];
     #endif
         //NSString *path = NSTemporaryDirectory();
         path = [path stringByAppendingString: @"/log.txt"];

         app_config->log_cfg.log_filename = pj_strdup3(app_config->pool,
                                                       [path UTF8String]);
       }
     #endif

       pjsua_media_config_default(&(app_config->media_cfg));

       // TODO select clock rate with enabled codec (8000 if nb codec only, or 16000 and more if wb codec)
       //app_config->media_cfg.clock_rate = 8000;
       //app_config->media_cfg.snd_clock_rate = 8000;
       app_config->media_cfg.clock_rate = 16000;
       app_config->media_cfg.snd_clock_rate = 16000;
       //app_config->media_cfg.ec_options = 0;//0=default,1=speex, 2=suppressor

       if (![[NSUserDefaults standardUserDefaults] boolForKey:@"enableEC"])
         app_config->media_cfg.ec_tail_len = 0;

       // Enable/Disable VAD/silence detector
       app_config->media_cfg.no_vad = [[NSUserDefaults standardUserDefaults]
                                       boolForKey:@"disableVad"];

       app_config->media_cfg.snd_auto_close_time = 0;
       //app_config->media_cfg.quality = 2;
       //app_config->media_cfg.channel_count = 2;

       app_config->media_cfg.enable_ice = [[NSUserDefaults standardUserDefaults]
                                           boolForKey:@"enableICE"];

       pjsua_transport_config_default(&(app_config->udp_cfg));
       val = [[NSUserDefaults standardUserDefaults] integerForKey: @"localPort"];
       if (val < 0 || val > 65535)
       {
         PJ_LOG(1,(THIS_FILE,
           "Error: local-port argument value (expecting 0-65535"));
         [app displayParameterError:
          @"Invalid value for Local Port (expecting 1-65535)."];

         status = PJ_EINVAL;
         goto error;
       }
       app_config->udp_cfg.port = val;

       pjsua_transport_config_default(&(app_config->rtp_cfg));
       app_config->rtp_cfg.port = [[NSUserDefaults standardUserDefaults]
         integerForKey: @"rtpPort"];
       if (app_config->rtp_cfg.port == 0)
       {
         enum { START_PORT=4000 };
         unsigned range;

         range = (65535-START_PORT-PJSUA_MAX_CALLS*4);
         app_config->rtp_cfg.port = START_PORT +
                 ((pj_rand() % range) & 0xFFFE);
       }

       if (app_config->rtp_cfg.port < 1 || app_config->rtp_cfg.port > 65535)
       {
         PJ_LOG(1,(THIS_FILE,
             "Error: rtp-port argument value (expecting 1-65535)"));
         [app displayParameterError:
          @"Invalid value for RTP port (expecting 1-65535)."];
         status = PJ_EINVAL;
         goto error;
       }

     #if 1 // TEST pour le vpn
       ip_addr = [[[NSUserDefaults standardUserDefaults] stringForKey:
                   @"boundAddr"] UTF8String];
       if (ip_addr && strlen(ip_addr))
       {
         pj_strdup2_with_null(app_config->pool,
                              &(app_config->udp_cfg.bound_addr),
                              ip_addr);
         pj_strdup2_with_null(app_config->pool,
                              &(app_config->rtp_cfg.bound_addr),
                              ip_addr);
       }

       ip_addr = [[[NSUserDefaults standardUserDefaults] stringForKey:
                   @"publicAddr"] UTF8String];
       if (ip_addr && strlen(ip_addr))
       {
         pj_strdup2_with_null(app_config->pool,
                              &(app_config->udp_cfg.public_addr),
                              ip_addr);
         pj_strdup2_with_null(app_config->pool,
                              &(app_config->rtp_cfg.public_addr),
                              ip_addr);
       }
     #endif

       /* Initialize application callbacks */
       app_config->cfg.cb.on_call_state = &on_call_state;
       app_config->cfg.cb.on_call_media_state = &on_call_media_state;
       app_config->cfg.cb.on_incoming_call = &on_incoming_call;
       app_config->cfg.cb.on_reg_state = &on_reg_state;
     #if defined(MWI) && MWI==1
       app_config->cfg.cb.on_mwi_info = &on_mwi_info;
       app_config->cfg.enable_unsolicited_mwi = PJ_TRUE;
     #endif

       srv = [[[NSUserDefaults standardUserDefaults] stringForKey:
                   @"stunServer"] UTF8String];
       if (srv && strlen(srv))
       {
         if (app_config->cfg.stun_srv_cnt==PJ_ARRAY_SIZE(app_config->cfg.stun_srv))
         {
           PJ_LOG(1,(THIS_FILE, "Error: too many STUN servers"));
           return PJ_ETOOMANY;
         }
         pj_strdup2_with_null(app_config->pool,
                              &(app_config->cfg.stun_srv[app_config->cfg.stun_srv_cnt++]),
                              srv);
       }

      // app_config->cfg.outbound_proxy[0] = pj_str(outbound_proxy);
      // app_config->cfg.outbound_proxy_cnt = 1;

       dns = [[NSUserDefaults standardUserDefaults] stringForKey: @"dnsServer"];
       array = [dns componentsSeparatedByString:@","];
       NSEnumerator *enumerator = [array objectEnumerator];
       NSString *anObject;
       while (anObject = [enumerator nextObject])
       {
         NSMutableString *mutableStr = [anObject mutableCopy];
         CFStringTrimWhitespace((CFMutableStringRef)mutableStr);
         srv = [mutableStr UTF8String];
         if (srv && strlen(srv))
         {
           if (app_config->cfg.nameserver_count==PJ_ARRAY_SIZE(app_config->cfg.nameserver))
           {
             PJ_LOG(1,(THIS_FILE, "Error: too many DNS servers"));
             [mutableStr release];
             break;
           }
           pj_strdup2_with_null(app_config->pool,
                                &(app_config->cfg.nameserver[app_config->cfg.nameserver_count++]),
                                srv);
         }
           [mutableStr release];
       }
       //[enumerator release];
       //[array release];

       /* Initialize pjsua */
       status = pjsua_init(&app_config->cfg, &app_config->log_cfg,
         &app_config->media_cfg);
       if (status != PJ_SUCCESS)
         goto error;

       /* Initialize Ring and Ringback */
       sip_ring_init(app_config);

       /* Add UDP transport. */
       status = pjsua_transport_create(PJSIP_TRANSPORT_UDP,
               &app_config->udp_cfg, &transport_id);
       if (status != PJ_SUCCESS)
         goto error;

       /* Add RTP transports */
      // status = pjsua_media_transports_create(&app_config->rtp_cfg);
      // if (status != PJ_SUCCESS)
       //  goto error;

     #if LOCAL_ACCOUNT
       {
         if (status == PJ_SUCCESS  && transport_id != -1)
         {
           /* Add local account */
           pjsua_acc_add_local(transport_id, PJ_TRUE, &aid);
         }
       }
     #endif

       /* */
       sip_manage_codec();

       /* Initialization is done, now start pjsua */
       status = pjsua_start();
       if (status != PJ_SUCCESS)
         goto error;

       return status;
     error:
       sip_cleanup(app_config);
       return status;
     }



 /* */
 pj_status_t sip_cleanup(app_config_t *app_config)
 {
   pj_status_t status;

   /* Cleanup Ring and Ringback */
   sip_ring_deinit(app_config);

   if (app_config->pool)
   {
     pj_pool_release(app_config->pool);
     app_config->pool = NULL;
   }

   /* Destroy pjsua */
   status = pjsua_destroy();

   pj_bzero(app_config, sizeof(app_config_t));

   return status;

 }

 /* */
 pj_status_t sip_connect(pj_pool_t *pool, pjsua_acc_id *acc_id)
 {
   pj_status_t status;
   pjsua_acc_config acc_cfg;
   const char *uname;
   const char *authname;
   const char *contactname;
   const char *passwd;
   const char *server;

   SiphonApplication *app = (SiphonApplication *)[SiphonApplication sharedApplication];

   // TODO Verify if wifi is connected, if not verify if user wants edge connection

   uname  = [[[NSUserDefaults standardUserDefaults] stringForKey:
              @"username"] UTF8String];
   authname  = [[[NSUserDefaults standardUserDefaults] stringForKey:
                 @"authname"] UTF8String];
   contactname  = [[[NSUserDefaults standardUserDefaults] stringForKey:
                 @"contact"] UTF8String];
   passwd = [[[NSUserDefaults standardUserDefaults] stringForKey:
              @"password"] UTF8String];
   server = [[[NSUserDefaults standardUserDefaults] stringForKey:
              @"server"] UTF8String];

   pjsua_acc_config_default(&acc_cfg);

   // ID
   acc_cfg.id.ptr = (char*) pj_pool_alloc(/*app_config.*/pool, PJSIP_MAX_URL_SIZE);
   if (contactname && strlen(contactname))
     acc_cfg.id.slen = pj_ansi_snprintf(acc_cfg.id.ptr, PJSIP_MAX_URL_SIZE,
                                        "\"%s\"<sip:%s@%s>", contactname, uname, server);
   else
     acc_cfg.id.slen = pj_ansi_snprintf(acc_cfg.id.ptr, PJSIP_MAX_URL_SIZE,
                                        "sip:%s@%s", uname, server);
   if ((status = pjsua_verify_sip_url(acc_cfg.id.ptr)) != 0)
   {
     PJ_LOG(1,(THIS_FILE, "Error: invalid SIP URL '%s' in local id argument",
       acc_cfg.id));
     [app displayParameterError: @"Invalid value for username or server."];
     return status;
   }

   // Registrar
   acc_cfg.reg_uri.ptr = (char*) pj_pool_alloc(/*app_config.*/pool,
     PJSIP_MAX_URL_SIZE);
   acc_cfg.reg_uri.slen = pj_ansi_snprintf(acc_cfg.reg_uri.ptr,
     PJSIP_MAX_URL_SIZE, "sip:%s", server);
   if ((status = pjsua_verify_sip_url(acc_cfg.reg_uri.ptr)) != 0)
   {
     PJ_LOG(1,(THIS_FILE,  "Error: invalid SIP URL '%s' in registrar argument",
       acc_cfg.reg_uri));
     [app displayParameterError: @"Invalid value for server parameter."];
     return status;
   }

   //acc_cfg.id = pj_str(id);
   //acc_cfg.reg_uri = pj_str(registrar);
   acc_cfg.cred_count = 1;
   acc_cfg.cred_info[0].scheme = pj_str("Digest");
   acc_cfg.cred_info[0].realm = pj_str("*");//pj_str(realm);
   if (authname && strlen(authname))
     acc_cfg.cred_info[0].username = pj_str((char *)authname);
   else
     acc_cfg.cred_info[0].username = pj_str((char *)uname);
   if ([[NSUserDefaults standardUserDefaults] boolForKey:@"enableMJ"])
     acc_cfg.cred_info[0].data_type = PJSIP_CRED_DATA_DIGEST;
   else
     acc_cfg.cred_info[0].data_type = PJSIP_CRED_DATA_PLAIN_PASSWD;
   acc_cfg.cred_info[0].data = pj_str((char *)passwd);

   acc_cfg.publish_enabled = PJ_TRUE;
 #if defined(MWI) && MWI==1
   acc_cfg.mwi_enabled = PJ_TRUE;
 #endif

   acc_cfg.allow_contact_rewrite = [[NSUserDefaults standardUserDefaults]
                                    boolForKey:@"enableNat"];

   // FIXME: gestion du message 423 dans pjsip
   acc_cfg.reg_timeout = [[NSUserDefaults standardUserDefaults] integerForKey:
     @"regTimeout"];

   if (acc_cfg.reg_timeout < 1 || acc_cfg.reg_timeout > 3600)
   {
     PJ_LOG(1,(THIS_FILE,
       "Error: invalid value for timeout (expecting 1-3600)"));
     [app displayParameterError:
           @"Invalid value for timeout (expecting 1-3600)."];
     return PJ_EINVAL;
   }

   // Keep alive interval
   acc_cfg.ka_interval = [[NSUserDefaults standardUserDefaults] integerForKey:
                     @"kaInterval"];

   // proxies server
   NSString *proxies = [[NSUserDefaults standardUserDefaults] stringForKey: @"proxyServer"];
   NSArray *array = [proxies componentsSeparatedByString:@","];
   NSEnumerator *enumerator = [array objectEnumerator];
   NSString *anObject;
   while (anObject = [enumerator nextObject])
   {
     NSMutableString *mutableStr = [anObject mutableCopy];
     CFStringTrimWhitespace((CFMutableStringRef)mutableStr);
     const char *proxy = [mutableStr UTF8String];
     if (proxy && strlen(proxy))
     {
       if (acc_cfg.proxy_cnt==PJ_ARRAY_SIZE(acc_cfg.proxy))
       {
         PJ_LOG(1,(THIS_FILE, "Error: too many proxy servers"));
         [mutableStr release];
         break;
       }
       pj_str_t pj_proxy;
       pj_proxy.slen = strlen(proxy) + 8;
       pj_proxy.ptr = (char*) pj_pool_alloc(pool, pj_proxy.slen);
       pj_proxy.slen = pj_ansi_snprintf(pj_proxy.ptr, pj_proxy.slen, "sip:%s;lr", proxy);
       if ((status = pjsua_verify_sip_url(pj_proxy.ptr)) != 0)
       {
         PJ_LOG(1,(THIS_FILE,  "Error: invalid SIP URL '%*.s' in proxy argument (%d)",
                   pj_proxy.slen, pj_proxy.ptr, status));
         [mutableStr release];
         [app displayParameterError: @"Invalid value for proxy parameter."];
         continue;
       }
       acc_cfg.proxy[acc_cfg.proxy_cnt++] = pj_proxy;
     }
     [mutableStr release];
   }

 #if LOCAL_ACCOUNT
  *acc_id = aid;
 #else
   status = pjsua_acc_add(&acc_cfg, PJ_TRUE, acc_id);
   if (status != PJ_SUCCESS)
   {
     pjsua_perror(THIS_FILE, "Error adding new account", status);
     [app displayParameterError: @"Error adding new account."];
   }
 #endif
   return status;
 }

 /* */
 pj_status_t sip_disconnect(pjsua_acc_id *acc_id)
 {
   pj_status_t status = PJ_SUCCESS;

   if (pjsua_acc_is_valid(*acc_id))
   {
     status = pjsua_acc_del(*acc_id);
     if (status == PJ_SUCCESS)
       *acc_id = PJSUA_INVALID_ID;
   }

   return status;
 }

 /* */
 pj_status_t sip_dial_with_uri(pjsua_acc_id acc_id, const char *uri,
                      pjsua_call_id *call_id)
 {
   // FIXME: récupérer le domain à partir du compte (acc_id);
   // TODO be careful app already mustn't be in communication!
   // TODO if not SIP connected, use GSM ? NSURL with 'tel' protocol
   pj_status_t status = PJ_SUCCESS;
   pj_str_t pj_uri;

 //  pjsua_msg_data msg_data;
 //  pjsip_generic_string_hdr subject;
 //  pj_str_t hvalue, hname;

   PJ_LOG(5,(THIS_FILE,  "Calling URI \"%s\".", uri));

   status = pjsua_verify_sip_url(uri);
   if (status != PJ_SUCCESS)
   {
     PJ_LOG(1,(THIS_FILE,  "Invalid URL \"%s\".", uri));
     pjsua_perror(THIS_FILE, "Invalid URL", status);
     return status;
   }

   pj_uri = pj_str((char *)uri);
  //status = pjsua_set_null_snd_dev();

   status =  pjsua_snd_is_active();

 //  hname = pj_str("Subject");
 //  hvalue = pj_str("phone call");
 //
 //  pjsua_msg_data_init(&msg_data);
 //  pjsip_generic_string_hdr_init2(&subject, &hname, &hvalue);
 //  pj_list_push_back(&msg_data.hdr_list, &subject);
 //
 //  status = pjsua_call_make_call(acc_id, &pj_uri, 0, NULL, &msg_data, call_id);
   status = pjsua_call_make_call(acc_id, &pj_uri, 0, NULL, NULL, call_id);
   if (status != PJ_SUCCESS)
   {
     pjsua_perror(THIS_FILE, "Error making call", status);
   }

   return status;
 }

 pj_status_t sip_dial(pjsua_acc_id acc_id, const char *number,
   pjsua_call_id *call_id)
 {
   // FIXME: récupérer le domain à partir du compte (acc_id);f
   // TODO be careful app already mustn't be in communication!
   // TODO if not SIP connected, use GSM ? NSURL with 'tel' protocol
   char uri[256];
   const char *sip_domain;

   sip_domain = [[[NSUserDefaults standardUserDefaults] stringForKey:
     @"server"] UTF8String];

   pj_ansi_snprintf(uri, 256, "sip:%s@%s", number, sip_domain);
   return sip_dial_with_uri(acc_id, uri, call_id);
 }

 /* */
 pj_status_t sip_answer(pjsua_call_id *call_id)
 {
   pj_status_t status;
     status = pjsua_set_null_snd_dev();

   status = pjsua_call_answer(*call_id, 200, NULL, NULL);
   if (status != PJ_SUCCESS)
   {
     *call_id = PJSUA_INVALID_ID;
   }

   return status;
 }

 /* */
 pj_status_t sip_hangup(pjsua_call_id *call_id)
 {
   pj_status_t status = PJ_SUCCESS;

   //pjsua_call_hangup_all();
   /* TODO Hangup current calls */
   if (*call_id != PJSUA_INVALID_ID)
     status = pjsua_call_hangup(*call_id, 0, NULL, NULL);
   *call_id = PJSUA_INVALID_ID;

   return status;
 }

 #if SETTINGS
 /* */
 pj_status_t sip_add_account(NSDictionary *account, pjsua_acc_id *acc_id)
 {
   pj_status_t status;
   pjsua_acc_config acc_cfg;
   const char *uname;
   const char *passwd;
   const char *server;
   const char *proxy;

   SiphonApplication *app = (SiphonApplication *)[SiphonApplication sharedApplication];
   app_config_t *app_config = [app pjsipConfig];

   // TODO Verify if wifi is connected, if not verify if user wants edge connection

   uname  = [[account objectForKey: @"username"] UTF8String];
   passwd = [[account objectForKey: @"password"] UTF8String];
   server = [[account objectForKey: @"server"] UTF8String];
   proxy  = [[account objectForKey: @"proxyServer"] UTF8String];

   pjsua_acc_config_default(&acc_cfg);

   // ID
   acc_cfg.id.ptr = (char*) pj_pool_alloc(app_config->pool, PJSIP_MAX_URL_SIZE);
   acc_cfg.id.slen = pj_ansi_snprintf(acc_cfg.id.ptr, PJSIP_MAX_URL_SIZE,
                                      "sip:%s@%s", uname, server);
   // FIXME : verify in settings view
   if ((status = pjsua_verify_sip_url(acc_cfg.id.ptr)) != 0)
   {
     PJ_LOG(1,(THIS_FILE, "Error: invalid SIP URL '%s' in local id argument",
               acc_cfg.id));
     [app displayParameterError: @"Invalid value for username or server."];
     return status;
   }

   // Registrar
   acc_cfg.reg_uri.ptr = (char*) pj_pool_alloc(app_config->pool,
                                               PJSIP_MAX_URL_SIZE);
   acc_cfg.reg_uri.slen = pj_ansi_snprintf(acc_cfg.reg_uri.ptr,
                                           PJSIP_MAX_URL_SIZE, "sip:%s", server);
   // FIXME : verify in settings view
   if ((status = pjsua_verify_sip_url(acc_cfg.reg_uri.ptr)) != 0)
   {
     PJ_LOG(1,(THIS_FILE,  "Error: invalid SIP URL '%s' in registrar argument",
               acc_cfg.reg_uri));
     [app displayParameterError: @"Invalid value for server parameter."];
     return status;
   }

   //acc_cfg.id = pj_str(id);
   //acc_cfg.reg_uri = pj_str(registrar);
   acc_cfg.cred_count = 1;
   acc_cfg.cred_info[0].scheme = pj_str("Digest");
   acc_cfg.cred_info[0].realm = pj_str("*");//pj_str(realm);
   acc_cfg.cred_info[0].username = pj_str((char *)uname);
   acc_cfg.cred_info[0].data_type = PJSIP_CRED_DATA_PLAIN_PASSWD;
   acc_cfg.cred_info[0].data = pj_str((char *)passwd);

   acc_cfg.publish_enabled = PJ_TRUE;

   acc_cfg.allow_contact_rewrite = [[account objectForKey:@"enableNat"] boolValue];

   // FIXME: gestion du message 423 dans pjsip
   acc_cfg.reg_timeout = [[account objectForKey: @"regTimeout"] intValue];
   // FIXME : verify in settings view
   if (acc_cfg.reg_timeout < 1 || acc_cfg.reg_timeout > 3600)
   {
     PJ_LOG(1,(THIS_FILE,
               "Error: invalid value for timeout (expecting 1-3600)"));
     [app displayParameterError:
      @"Invalid value for timeout (expecting 1-3600)."];
     return PJ_EINVAL;
   }

   pj_str_t pj_proxy = pj_str((char *)proxy);
   if (pj_strlen(&pj_proxy) > 0)
   {
     acc_cfg.proxy[0].ptr = (char*) pj_pool_alloc(app_config->pool,
                                                  PJSIP_MAX_URL_SIZE);
     acc_cfg.proxy[0].slen = pj_ansi_snprintf(acc_cfg.proxy[0].ptr,
                                              PJSIP_MAX_URL_SIZE, "sip:%s;lr", proxy);
     // FIXME verify in settings view
     if ((status = pjsua_verify_sip_url(acc_cfg.proxy[0].ptr)) != 0)
     {
       PJ_LOG(1,(THIS_FILE,  "Error: invalid SIP URL '%s' in proxy argument",
                 acc_cfg.reg_uri));
       [app displayParameterError: @"Invalid value for proxy parameter."];
       return status;
     }
     acc_cfg.proxy_cnt = 1;
   }

   status = pjsua_acc_add(&acc_cfg, PJ_TRUE, acc_id);
   if (status != PJ_SUCCESS)
   {
     pjsua_perror(THIS_FILE, "Error adding new account", status);
     [app displayParameterError: @"Error adding new account."];
   }

   return status;
 }
 #endif
 */
