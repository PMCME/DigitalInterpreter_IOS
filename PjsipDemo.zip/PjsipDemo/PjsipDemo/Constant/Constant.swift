//
//  Constant.swift
//  PjsipDemo
//
//  Created by Apple on 24/05/23.
//

import Foundation

class Constant: NSObject {
    
    struct NotificationName {
        static let HangUpCallBack = Notification.init(name: Notification.Name("HangUpCallBack"))
        static let GetRegisterUserCallBack = Notification.init(name: Notification.Name("GetRegisterUserCallBack"))
    }
}
