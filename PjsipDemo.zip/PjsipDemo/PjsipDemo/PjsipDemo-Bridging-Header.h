//
//  Use this file to import your target's public headers that you would like to expose to Swift.
//

#define PJ_AUTOCONF 1

//#import "wrapper.h"
//#import <PJSIP/pjsua.h>
#import "pjsua.h"
