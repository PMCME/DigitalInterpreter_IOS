//
//  WebRTCClient.swift
//  PjsipDemo
//
//  Created by Apple on 24/05/23.
//

import UIKit

//MARK: Private Function
func on_call_state(call_id: pjsua_call_id, e: UnsafeMutablePointer<pjsip_event>?) {
    
    var ci = pjsua_call_info();
    pjsua_call_get_info(call_id, &ci);
    print("on call state: \(ci.state.rawValue)")
    if (ci.state == PJSIP_INV_STATE_DISCONNECTED) {
        /* UIView update must be done in the main thread */
       // DispatchQueue.main.sync {
            dismissVideoViewController()
            print("Coming in On Call State")
       // }
    }
}

 func on_reg_state2(acc_id: pjsua_acc_id, info: UnsafeMutablePointer<pjsua_reg_info>?) {
    
     var accinfo =  pjsua_acc_info()
     pjsua_acc_get_info(acc_id, &accinfo)
     print("registration text: \(accinfo.status_text)")
     var success = true
    if accinfo.status.rawValue !=  200 {
       success = false
    }
     print("print: \(success)--\(accinfo.status.rawValue)")
     NotificationCenter.default.post(name: Constant.NotificationName.GetRegisterUserCallBack.name, object: nil , userInfo: ["success" : success])
}


 func tupleToArray<Tuple, Value>(tuple: Tuple) -> [Value] {
    let tupleMirror = Mirror(reflecting: tuple)
    return tupleMirror.children.compactMap { (child: Mirror.Child) -> Value? in
        return child.value as? Value
    }
}

 func on_call_media_state(call_id: pjsua_call_id) {
    var ci = pjsua_call_info();
    pjsua_call_get_info(call_id, &ci);

    for mi in 0...ci.media_cnt {
        let media: [pjsua_call_media_info] = tupleToArray(tuple: ci.media);

        if (media[Int(mi)].status == PJSUA_CALL_MEDIA_ACTIVE ||
            media[Int(mi)].status == PJSUA_CALL_MEDIA_REMOTE_HOLD)
        {
            switch (media[Int(mi)].type) {
            case PJMEDIA_TYPE_AUDIO:
                var call_conf_slot: pjsua_conf_port_id;

                call_conf_slot = media[Int(mi)].stream.aud.conf_slot;
                pjsua_conf_connect(call_conf_slot, 0);
                pjsua_conf_connect(0, call_conf_slot);
//                if ci.media_cnt == 1 { //Audio call only
//                    DispatchQueue.main.sync {
//                        displayVideoView(UIView())
//                    }
//                }

                break;
        
            case PJMEDIA_TYPE_VIDEO:
                let wid = media[Int(mi)].stream.vid.win_in;
                var wi = pjsua_vid_win_info();
                    
                if (pjsua_vid_win_get_info(wid, &wi) == PJ_SUCCESS.rawValue) {
                    let vid_win:UIView =
                        Unmanaged<UIView>.fromOpaque(wi.hwnd.info.ios.window).takeUnretainedValue();

                    /* UIView update must be done in the main thread */
                    DispatchQueue.main.sync {
                        print("Coming in on_call_media_state")
                         displayVideoView(vid_win)
                       // AppDelegate.Shared.vinfo.vid_win = vid_win;
                    }
                }
                break;
            
            default:
                break;
            }
        }
    }
}

/*(pjsua_acc_id acc_id, pjsua_call_id call_id,
 pjsip_rx_data *rdata)*/
 func on_incoming_call(acc_id: pjsua_acc_id, call_id: pjsua_call_id, rdata: UnsafeMutablePointer<pjsip_rx_data>?) {
    print("Incoming call is received-- \(acc_id)")
    var ci: pjsua_call_info = pjsua_call_info()
    var opt: pjsua_call_setting = pjsua_call_setting()
    pjsua_call_setting_default(&opt)
    var pParam: pjsua_vid_preview_param = pjsua_vid_preview_param()
    pjsua_vid_preview_param_default(&pParam)
    
    pParam.show = pj_bool_t(PJ_TRUE.rawValue);
    
    opt.aud_cnt = 1 // number of simultaneous audio calls
    opt.vid_cnt = 1 // number of simultaneous video calls
    
//    free(accId)
     //free(rdata)
   
    
    pjsua_call_get_info(call_id, &ci)
    
  //  PJ_LOG(3, (THIS_FILE, "Incoming call from %.*s!!",
 //               Int32(ci.remote_info.slen),
 //               ci.remote_info.ptr))
    pjsua_call_answer2(call_id, &opt, 200, nil, nil)
}




 func call_func(user_data: UnsafeMutableRawPointer? , account_id : pjsua_acc_id) {
    print("Going in call function")
    let pjsip_vars = Unmanaged<PjsipVars>.fromOpaque(user_data!).takeUnretainedValue()
    if (!pjsip_vars.calling) {
        var status: pj_status_t;
        var opt = pjsua_call_setting();

        pjsua_call_setting_default(&opt);
        opt.aud_cnt = 1;
        opt.vid_cnt = 1;
        
         print("Destinlation URL:\(pjsip_vars.dest)")
        let dest_str = strdup(pjsip_vars.dest);
        var dest:pj_str_t = pj_str(dest_str);
        status = pjsua_call_make_call(account_id, &dest, &opt, nil, nil, &pjsip_vars.call_id);//&pjsip_vars.call_id
        if (status != PJ_SUCCESS.rawValue)
        {
            print("error making in call")
           //pjsua_perror(THIS_FILE, "Error making call", status);
        }
//        DispatchQueue.main.sync {
//            pjsip_vars.calling = (status == PJ_SUCCESS.rawValue);
//        }
        free(dest_str);
    } else {
        if (pjsip_vars.call_id != PJSUA_INVALID_ID.rawValue) {
            DispatchQueue.main.sync {
                pjsip_vars.calling = false;
            }
            pjsua_call_hangup(pjsip_vars.call_id, 200, nil, nil);
            pjsip_vars.call_id = PJSUA_INVALID_ID.rawValue;
        }
    }

}
